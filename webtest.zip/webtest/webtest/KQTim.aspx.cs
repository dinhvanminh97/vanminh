﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;


namespace webtest
{
    public partial class KQTim : System.Web.UI.Page
    {

        ketnoi kn = new ketnoi();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["noidung"] != null)
            {
                string thongtintimkiem = Request.QueryString["noidung"];
                DataTable dt = kn.getTable(@"SELECT * FROM THONGTINPHONG WHERE MaPhong like '%" + thongtintimkiem + 
                            @"%' or MaPhong like '%" + thongtintimkiem + "' or MaPhong like '" + thongtintimkiem + 
                            @"%' or TenPhong like '%" + thongtintimkiem + "' or TenPhong like '" + thongtintimkiem +
                            @"%' or  MaPhong like '%" + thongtintimkiem + "%' or  LoaiPhong like '%" + thongtintimkiem + 
                            @"%' or  LoaiPhong like '" + thongtintimkiem + "%' or  LoaiPhong like '%" + thongtintimkiem + 
                            @"' or  ThongTinChiTietPhong like '%" + thongtintimkiem + "%' or  ThongTinChiTietPhong like '%" + thongtintimkiem + 
                            @"' or  ThongTinChiTietPhong like '" + thongtintimkiem + "%'");
                lbthongtin.Text = dt.Rows.Count.ToString(); 
                if(dt.Rows.Count==0){
                    lbthongtin.Text = "Không tìm thấy kết quả với từ khóa '"+Request.QueryString["noidung"]+"'";
                }
                else
                {
                    string noidung = "Có " + dt.Rows.Count + " Kết quả được tìm thấy với từ khóa '" + Request.QueryString["noidung"] + "' <br/>";
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        noidung = noidung + "<img  src='picture/thongtinPhong/" + dt.Rows[i]["HinhAnh"] + @"'/>";
                    }
                    lbthongtin.Text = noidung;
                }
                
            }
            else
            {
                Response.Redirect("trangchu.aspx?");
            }
     
        }
        
    }
}