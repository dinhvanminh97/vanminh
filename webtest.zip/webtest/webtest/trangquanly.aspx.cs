﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace webtest
{
    public partial class trangquanly : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"] == null)
            {
                Response.Redirect("dangnhap.aspx");    
            }

            lblThongtinDangNhap.Text = "<h1 style='color:#0000FF; background:#FFF5EE'>Xin chào " + Session["username"] + " đã đến với trang quản lý Khách Sạn<br />Mời chọn chức năng quản lý</h1>";
        }
    }
}