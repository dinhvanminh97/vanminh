﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace webtest
{
    public partial class trangchu : System.Web.UI.Page
    {
        string s = WebConfigurationManager.ConnectionStrings["csdlweb"].ToString();
        SqlDataAdapter da = new SqlDataAdapter();
        DataTable dt = new DataTable();

        protected void Page_Load(object sender, EventArgs e)
        {
            /*
            if(!IsPostBack){
                getdata();
            }
             */
        }

        protected void btnxemchitiet_Click(object sender, EventArgs e)
        {
            Response.Redirect("chitiet.aspx");
        }

        protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        /*
        public void getdata() {
            string sql = "";
            SqlConnection con = new SqlConnection(s);
            SqlCommand cm = new SqlCommand();
            try
            {
                con.Open();
                cm.Connection = con;
                sql = " select * from THONGTINSP";
                cm.CommandText = sql;
                cm.CommandType = CommandType.Text;
                da.SelectCommand = cm;
                da.Fill(dt);
                DataListSP.DataSource = dt;
                DataListSP.DataBind();
            }
            catch
            {
             
            }
            finally
            {
                con.Close();
                con.Dispose();
            }

        }*/
    }
}