﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data;
using System.Web.Configuration;

namespace webtest
{
    public partial class quanlyphong : System.Web.UI.Page
    {
        ketnoi kn = new ketnoi();
        string s = WebConfigurationManager.ConnectionStrings["csdlweb"].ToString();
        SqlDataAdapter da = new SqlDataAdapter();
        DataTable dt = new DataTable();

        public void laybangchogridview()
        {

            string sql = "";
            SqlConnection con = new SqlConnection(s);
            SqlCommand cm = new SqlCommand();
            try
            {
                con.Open();
                cm.Connection = con;
                sql = " select * from THONGTINPHONG";
                cm.CommandText = sql;
                cm.CommandType = CommandType.Text;
                da.SelectCommand = cm;
                da.Fill(dt);
                gvdanhsachphong.DataSource = dt;
                gvdanhsachphong.DataBind();
            }
            catch
            {
             
            }
            finally
            {
                con.Close();
                con.Dispose();
            }

        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack){
                laybangchogridview();
                //ẩn không cho sử dụng
                btnluu.Enabled = false;
                btnhuy.Enabled = false;

                txtmaphong.Focus();

                lblthongbao.Text = "";

                btnco.Visible = false;//không hiển thị
                btnkhong.Visible = false;

                ViewState["flag"] = false;// khi load lên cái này sẽ thực hiện bên nút sữa chứ k bên nút thêm

                //khai báo lớp kết nối để lấy dữ liệu bảng
                /*
                app_code.ketnoi kn = new app_code.ketnoi();
                DataTable dt = new DataTable();
                dt = kn.laybang("select * from THONGTINPHONG");
                gvdanhsachphong.DataSource = dt;
                gvdanhsachphong.DataBind();
                */
            }
            
        }

        protected void btnthem_Click(object sender, EventArgs e)
        {
            txtmaphong.Text = "";
            txttenphong.Text = "";
            txtgia.Text = "";
            Showhinhanh.Text = "";
            
            txtmaphong.Focus();
            txtmaphong.ReadOnly = false;
            btnco.Enabled = true;
            btnhuy.Enabled = true;

            btnthem.Enabled = false;
            btnxoa.Enabled = false;
            btnsua.Enabled = false;

            btnluu.Enabled = true;
            btnhuy.Enabled = true;
            ViewState["flag"] = true;//đánh dấu nó vì bên update cũng dùng chung lệnh cuối
            
            
             
        }



        protected void gvdanhsachphong_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnxoa.Focus();
            btnthem.Enabled = true;
            btnsua.Enabled = true;
            btnxoa.Enabled = true;
            btnluu.Enabled = false;
            btnhuy.Enabled = false;

            txtmaphong.ReadOnly = true;
            txtmaphong.Text = gvdanhsachphong.SelectedRow.Cells[0].Text;
            txttenphong.Text = gvdanhsachphong.SelectedRow.Cells[1].Text;
            DropDownLoaiPhong.SelectedValue = gvdanhsachphong.SelectedRow.Cells[2].Text;
            txtgia.Text = gvdanhsachphong.SelectedRow.Cells[3].Text;
            Showhinhanh.Text = "<img src='/picture//img/" + gvdanhsachphong.SelectedRow.Cells[4].Text.ToString() + "' style='width: 200px; height: auto'/>";
            
        }

        protected void btnxoa_Click(object sender, EventArgs e)
        {
            lblthongbao.Text = "Bạn có muốn xóa không?";
            btnco.Focus();

            btnco.Visible = true; // khi bấm xóa nó sẽ hiện 2 nút này ra
            btnkhong.Visible = true;
        }

        protected void btnco_Click(object sender, EventArgs e)
        {
            
            SqlConnection con = new SqlConnection(@"server=DESKTOP-U87VVT9\SQLEXPRESS;database=demo;Integrated security=true;");
            SqlCommand cmd = new SqlCommand("delete from THONGTINPHONG  where MaPhong='" + txtmaphong.Text + "'", con);
            con.Open(); // mo ket noi
            cmd.ExecuteNonQuery(); // thuc thi
            con.Close();

                lblthongbao.Text = "Bạn đã xóa thành công";

                laybangchogridview();

                btnco.Visible = false;
                btnkhong.Visible = false;

                txtmaphong.Text = "";

            txtmaphong.Focus();
            txttenphong.Text = "";
            txtgia.Text = "";
          }

        protected void btnkhong_Click(object sender, EventArgs e)
        {
            btnco.Visible = false;
            btnkhong.Visible = false;
            lblthongbao.Text = "";
        }

        protected void btnsua_Click(object sender, EventArgs e)
        {

            txtmaphong.Enabled = false;
            txttenphong.Focus();
            btnluu.Enabled = true;
            btnhuy.Enabled = true;
        }

        protected void btnluu_Click(object sender, EventArgs e)
        {

            btnthem.Enabled = true;
            btnsua.Enabled = true;
            btnxoa.Enabled = true;
            btnluu.Enabled = false;
            btnhuy.Enabled = false;

            if (txtmaphong.ReadOnly == false)
            {
                Luu();
            }
            else
            {
                Sua();
            }
            

        }

        protected void btnhuy_Click(object sender, EventArgs e)
        {
            btnthem.Enabled = true;
            btnsua.Enabled = true;
            btnxoa.Enabled = true;
            btnluu.Enabled = false;
            btnhuy.Enabled = false;
            txtmaphong.Text = "";

            txtmaphong.Focus();
            txttenphong.Text = "";
            txtgia.Text = "";
        }

        protected void btnquaylai_Click(object sender, EventArgs e)
        {
            Response.Redirect("trangquanly.aspx");
        }

        private void Luu()
        {
            if (txtgia.Text.ToString() != "" && txttenphong.Text.ToString() != "" && txtmaphong.Text.ToString() != "" && hinhanh.FileContent.Length > 0)
            {

                DataTable dt = kn.getTable("SELECT * FROM THONGTINPHONG WHERE MaPhong = '" + txtmaphong.Text.ToString() + "'");
                if (dt.Rows.Count > 0)
                {
                    Response.Write("<script>alert('Mã phong đã tồn tại. Vui long chọn mã mới')</script>");
                }
                else
                {
                    string sql = @"INSERT INTO [dbo].[THONGTINPHONG](
                                        [MaPhong]
                                       ,[TenPhong]
                                       ,[LoaiPhong]
                                       ,[Gia]
                                       ,[HinhAnh])
                                 VALUES
                                       ('" + txtmaphong.Text.ToString() + @"'
                                       ,'" + txttenphong.Text.ToString() + @"'
                                       ,'" + DropDownLoaiPhong.SelectedValue.ToString() + @"'
                                       ," + float.Parse(txtgia.Text.ToString()) + @"
                                       ,'" + hinhanh.FileName.ToString() + @"')";

                    int rs = kn.XuLy(sql);

                    if (hinhanh.FileName.EndsWith(".jpe") || hinhanh.FileName.EndsWith(".jpg") || hinhanh.FileName.EndsWith(".png") || hinhanh.FileName.EndsWith(".gif"))
                    {
                        hinhanh.SaveAs(Server.MapPath("picture\\img\\ " + hinhanh.FileName));
                    }
                    laybangchogridview();
                    Response.Write("<script>alert('Thêm phòng thành công')</script>");
                }

            }
            else
            {
                Response.Write("<script>alert('Vui lòng kiểm tra thông tin đã nhập')</script>");
            }
        }

        private void Sua(){
            if (txtgia.Text.ToString() != "" && txttenphong.Text.ToString() != "" )
            {
                string Anh = "";
                if (hinhanh.FileContent.Length > 0)
                {
                    Anh = hinhanh.FileName.ToString();
                    string sql = @"UPDATE [dbo].[THONGTINPHONG]
                               SET 
                                   [TenPhong] ='" + txttenphong.Text.ToString() + @"'
                                  ,[LoaiPhong] = '" + DropDownLoaiPhong.SelectedValue.ToString() + @"'
                                  ,[Gia] = " + float.Parse(txtgia.Text.ToString()) + @"
                                  ,[HinhAnh] = '" + Anh + @"'
                             WHERE [MaPhong] = '" + txtmaphong.Text.ToString() + @"'";

                    int rs = kn.XuLy(sql);

                    if (hinhanh.FileName.EndsWith(".jpe") || hinhanh.FileName.EndsWith(".jpg") || hinhanh.FileName.EndsWith(".png") || hinhanh.FileName.EndsWith(".gif"))
                    {
                        hinhanh.SaveAs(Server.MapPath("picture\\thongtinphong\\ " + hinhanh.FileName));
                    }
                    laybangchogridview();
                    Response.Write("<script>alert('Sửa phòng thành công')</script>");
                
                }
                else
                {
                    Anh = gvdanhsachphong.SelectedRow.Cells[4].Text.ToString();
                    string sql = @"UPDATE [dbo].[THONGTINPHONG]
                               SET 
                                   [TenPhong] ='" + txttenphong.Text.ToString() + @"'
                                  ,[LoaiPhong] = '" + DropDownLoaiPhong.SelectedValue.ToString() + @"'
                                  ,[Gia] = " + float.Parse(txtgia.Text.ToString()) + @"
                                  ,[HinhAnh] = '" + Anh + @"'
                             WHERE [MaPhong] = '" + txtmaphong.Text.ToString() + @"'";

                    int rs = kn.XuLy(sql);
                    laybangchogridview();
                    Response.Write("<script>alert('Sửa phòng thành công')</script>");
                
                }
                
                }
            else
            {
                Response.Write("<script>alert('Vui lòng kiểm tra thông tin đã nhập')</script>");
            }
        }
        }
        
   

    }

