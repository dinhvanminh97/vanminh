﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace webtest
{
    public class ketnoi
    {

        string connectionString = @"Data Source=DESKTOP-U87VVT9\SQLEXPRESS;Initial Catalog=demo;User ID=sa;Password=123";



        //Lấy dữ liệu từ một table bất kỳ
        public DataTable getTable(string query)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataTable tb = new DataTable();
            da.Fill(tb);
            return tb;
        }

        public int XuLy(String sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            int rs = cmd.ExecuteNonQuery();
            con.Close();
            return rs;
        }
    }
}