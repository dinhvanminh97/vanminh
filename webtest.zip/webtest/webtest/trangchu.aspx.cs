﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;


namespace webtest
{
	public partial class trangchu1 : System.Web.UI.Page
	{

        //ketnoi kn = new ketnoi();

		protected void Page_Load(object sender, EventArgs e)
		{
            /*
                string sql = "SELECT * FROM THONGTINPHONG";
                string noidung = "";
                DataTable dt = kn.getTable(sql);
                if (dt.Rows.Count > 0)
                {
                    if (dt.Rows.Count < 3)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            noidung  = noidung + @"
                                                <div style='width:200px; height:200px; padding-right:10px; float:left'>
                                                    <img  src='picture/thongtinPhong/" + dt.Rows[i]["HinhAnh"] + @"'/>
                                                    
                                                </div>";
                        }
                    }
                    else {
                        for (int i = 0; i < 3; i++)
                        {
                            noidung = noidung + @"
                                                <div style='width:200px; height:200px; padding-right:10px; float:left'>
                                                    <img  src='picture/thongtinPhong/" + dt.Rows[i]["HinhAnh"] + @"'/>
                                                    
                                                </div>";
                        }
                    }

                }
                lblshowthongtinKS.Text = noidung;
                
           */
		}

        
        }
	}