﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace webtest
{
    public partial class dangnhap : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
                       SqlConnection cn = new SqlConnection(@"Data Source=DESKTOP-U87VVT9\SQLEXPRESS;Initial Catalog=demo;Integrated Security=True");
                       txtusername.Focus();
            cn.Open();
            string sql = "select * from DANGNHAP where username='"+txtusername.Text +" 'and password='"+ txtpassword.Text +"'";
            SqlCommand con = new SqlCommand(sql,cn);
            SqlDataReader dt=con.ExecuteReader();
            bool check = dt.Read();
            if (txtusername.Text == "" || txtpassword.Text == "")
            {
                //Response.Write("<script>alert('Vui lòng nhập đầy đủ thông tin')</script>");
                lblthongbao.Text = "Vui lòng nhập đầy đủ thông tin";
            }
            else
                 if(check){
                Session.Add("username", txtusername.Text);
                Session.Add("password", txtpassword.Text);
                Response.Redirect("trangquanly.aspx");

              }
               
                else
  
                     {
                        Response.Write("<script>alert('Sai tên đăng nhập hoặc mật khẩu')</script>");
                    
                     }
               
            }
        }
    }