﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace webtest
{
    public partial class quanlynhanvien : System.Web.UI.Page
    {
       ketnoi kn = new ketnoi();
        string s = WebConfigurationManager.ConnectionStrings["csdlweb"].ToString();
        SqlDataAdapter da = new SqlDataAdapter();
        DataTable dt = new DataTable();

        public void laybangchoGRV()
        {
            string sql = "";
            SqlConnection con = new SqlConnection(s);
            SqlCommand cm = new SqlCommand();

            try
            {
                con.Open();
                cm.Connection = con;
                sql = "select * from NHANVIEN";
                cm.CommandText = sql;
                cm.CommandType = CommandType.Text;
                da.SelectCommand = cm;
                da.Fill(dt);
                GRVNV.DataSource = dt;
                GRVNV.DataBind();
            }
            catch
            {

            }
            finally
            {
                con.Close();
                con.Dispose();
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                laybangchoGRV();

                lblthongbao.Text = "";

                btnco.Visible = false;//không hiển thị
                btnkhong.Visible = false;

                
            }

        }

        protected void btnthem_Click(object sender, EventArgs e)
        {

            txtmaNV.Text = "";
            txthoten.Text = "";
            txtngaysinh.Text = "";
            txtsocmnn.Text = "";
            txtdiachi.Text = "";

            txtmaNV.Focus();
            txtmaNV.ReadOnly = false;
            btnco.Enabled = true;
            btnhuy.Enabled = true;

            btnthem.Enabled = false;
            btnxoa.Enabled = false;
            btnsua.Enabled = false;

            btnluu.Enabled = true;
            btnhuy.Enabled = true;
            ViewState["flag"] = true;//đánh dấu nó vì bên update cũng dùng chung lệnh cuối
        }

        public void themnv()
        {
            SqlConnection con = new SqlConnection(@"server=DESKTOP-U87VVT9\SQLEXPRESS;database=demo;Integrated Security=true;");

            SqlCommand cmd = new SqlCommand("insert into NHANVIEN(MaNV,HoTen,NgaySinh,GioiTinh,SCMNN,DiaChi) values('" + txtmaNV.Text + "','" + txthoten.Text + "','" + txtngaysinh.Text + "','" + DropDownList1gioitinh.Text + "','" + txtsocmnn.Text + "','" + txtdiachi.Text + "')", con);
            con.Open(); // mo ket noi
            cmd.ExecuteNonQuery(); // thuc thi
            laybangchoGRV();
            con.Close();
        }

        protected void btnluu_Click(object sender, EventArgs e)
        {
            btnthem.Enabled = true;
            btnsua.Enabled = true;
            btnxoa.Enabled = true;
            btnluu.Enabled = false;
            btnhuy.Enabled = false;

            if (txtmaNV.ReadOnly == false)
            {
                Luu();
            }
            else
            {
                Sua();
            }
        }

        private void Luu()
        {
            if (txtmaNV.Text.ToString() != "" && txthoten.Text.ToString() != "" && txtngaysinh.Text.ToString() != "" && txtngaysinh.Text.ToString() != ""&& DropDownList1gioitinh.Text.ToString() != ""&& txtsocmnn.Text.ToString() != ""&& txtdiachi.Text.ToString() != "")
            {

                DataTable dt = kn.getTable("SELECT * FROM NHANVIEN WHERE MaNV = '" + txtmaNV.Text.ToString() + "'");
                if (dt.Rows.Count > 0)
                {
                    Response.Write("<script>alert('Mã nhân viên đã tồn tại. Vui long chọn mã mới')</script>");
                }
                else
                {
                    string sql = @"INSERT INTO [dbo].[NHANVIEN](
                                        [MaNV]
                                       ,[HoTen]
                                       ,[NgaySinh]
                                       ,[GioiTinh]
                                       ,[SCMNN]
                                       ,[DiaChi])
                                 VALUES
                                       ('" + txtmaNV.Text.ToString() + @"'
                                       ,'" + txthoten.Text.ToString() + @"'
                                       ,'" + txtngaysinh.Text.ToString() + @"'
                                       ,'" + DropDownList1gioitinh.SelectedValue.ToString() + @"'
                                       ,'" + txtsocmnn.Text.ToString() + @"'
                                       ,'" + txtdiachi.Text.ToString() + @"')";

                    int rs = kn.XuLy(sql);

                   
                    laybangchoGRV();
                    Response.Write("<script>alert('Thêm nhân viên thành công')</script>");
                }

            }
            else
            {
                Response.Write("<script>alert('Vui lòng kiểm tra thông tin đã nhập')</script>");
            }
        }

        private void Sua(){
            if (txthoten.Text.ToString() != "" && txtngaysinh.Text.ToString() != "" && DropDownList1gioitinh.SelectedValue.ToString() != "" && txtsocmnn.Text.ToString() != "" && txtdiachi.Text.ToString() != "")
            {
                
                    string sql = @"UPDATE [dbo].[NHANVIEN]
                               SET 
                                   [HoTen] ='" + txthoten.Text.ToString() + @"'
                                  ,[NgaySinh] ='" + txtngaysinh.Text.ToString() + @"'
                                  ,[GioiTinh] = '" + DropDownList1gioitinh.SelectedValue.ToString() + @"'
                                  ,[SCMNN] ='" + txtsocmnn.Text.ToString() + @"'
                                  ,[DiaChi] ='" + txtdiachi.Text.ToString() + @"'
                             WHERE [MaNV] = '" + txtmaNV.Text.ToString() + @"'";

                    int rs = kn.XuLy(sql);

                    
                    laybangchoGRV();
                    Response.Write("<script>alert('Sửa thông tin thành công')</script>");
                
                }                
                
            else
            {
                Response.Write("<script>alert('Vui lòng kiểm tra thông tin đã nhập')</script>");
            }
        }

        protected void btnxoa_Click(object sender, EventArgs e)
        {
            lblthongbao.Text = "Bạn có muốn xóa không?";
            btnco.Focus();

            btnco.Visible = true; // khi bấm xóa nó sẽ hiện 2 nút này ra
            btnkhong.Visible = true;
        }

        protected void btnco_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"server=DESKTOP-U87VVT9\SQLEXPRESS;database=demo;Integrated security=true;");
            SqlCommand cmd = new SqlCommand("delete from NHANVIEN  where MaNV='" + txtmaNV.Text + "'", con);
            con.Open(); // mo ket noi
            cmd.ExecuteNonQuery(); // thuc thi
            con.Close();

            lblthongbao.Text = "Bạn đã xóa thành công";

            laybangchoGRV();

            btnco.Visible = false;
            btnkhong.Visible = false;

            txtmaNV.Text = "";

            txtmaNV.Focus();
            txthoten.Text = "";
            txtngaysinh.Text = "";
            txtsocmnn.Text = "";
            txtdiachi.Text = "";
        }

        protected void GRVNV_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnxoa.Focus();
            btnthem.Enabled = true;
            btnsua.Enabled = true;
            btnxoa.Enabled = true;
            btnluu.Enabled = false;
            btnhuy.Enabled = false;

            txtmaNV.Text = GRVNV.SelectedRow.Cells[0].Text;
            txthoten.Text = GRVNV.SelectedRow.Cells[1].Text;
            txtngaysinh.Text = GRVNV.SelectedRow.Cells[2].Text;
            DropDownList1gioitinh.SelectedValue = GRVNV.SelectedRow.Cells[2].Text;
            txtsocmnn.Text = GRVNV.SelectedRow.Cells[4].Text;
            txtdiachi.Text = GRVNV.SelectedRow.Cells[4].Text;
        }

        protected void btnquaylai_Click(object sender, EventArgs e)
        {
            Response.Redirect("trangquanly.aspx");
        }

        protected void btnhuy_Click(object sender, EventArgs e)
        {
            btnco.Visible = false;
            btnkhong.Visible = false;
            lblthongbao.Text = "";
        }

        protected void btnkhong_Click(object sender, EventArgs e)
        {
            btnco.Visible = false;
            btnkhong.Visible = false;
            lblthongbao.Text = "";
        }

        protected void btnsua_Click(object sender, EventArgs e)
        {
            txtmaNV.Enabled = false;
            txthoten.Focus();
            btnluu.Enabled = true;
            btnhuy.Enabled = true;
        }

       

    }
}
    
