﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace webtest
{
    public partial class index : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"] == null)
            {
                btnShowDangNhap.Text = "<li><a href='dangnhap.aspx'>Đăng Nhập</a></li> ";
            }
            else
            {
                btnShowDangNhap.Text = @"<li><a href='#'> Xin chào: "+Session["username"]+@"</a>
                        <ul>   
                             <li>
                                 <a href = 'Dangxuat.aspx'>Đăng xuất</a></li>
                            
                        </ul>
                    </li>  ";
            }
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void txttimkiem_TextChanged(object sender, EventArgs e)
        {
            if (txttimkiem.Text == "")
            {

                Response.Write("<script>alert('Bạn Phải Nhập Từ Khoá Trước Khi Tìm >.<!...')</script>");

            }

            else
            {

                //string ProName = txttimkiem.Text;

                //string chuoitimkiem = string.Parse(txttimkiem.SelectedItem.Value.ToString());

               

                //Response.Redirect("KQTim.aspx?ProName=" + ProName + "&chuoitimkiem=" + chuoitimkiem);

            }
        }

        protected void btnTimKiem_Click(object sender, EventArgs e)
        {
            if (txttimkiem.Text != null && txttimkiem.Text.Length > 0)
            {
                Response.Redirect("KQTim.aspx?noidung=" + txttimkiem.Text + "");
            }
        }

        
    }
}